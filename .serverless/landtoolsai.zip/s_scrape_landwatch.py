import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='lancejohnson',
    application_name='landtoolsai',
    app_uid='mlwtCNL6vYj9wZXt5p',
    org_uid='sVd8x6W50Z8Y39My3s',
    deployment_uid='a01d84f3-fc7d-4bce-98f2-5bc9ab6b0c97',
    service_name='landtoolsai',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.6.12',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'landtoolsai-dev-scrape_landwatch', 'timeout': 900}
try:
    user_handler = serverless_sdk.get_user_handler('scrape_landwatch.scrape_landwatch')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
